'''#####-----Build File-----#####'''
buildfile = 'https://www.dropbox.com/scl/fi/c6224u5pndwlmq4ijyx72/builds.txt?rlkey=k22wa3ppn7jk3yewbyrcp2815&st=oslmzpx4&dl=1'

'''#####-----Videos File-----#####'''
videos_url = 'http://'

'''#####-----Notification File-----#####'''
notify_url  = 'https://www.dropbox.com/scl/fi/sw0oc07yce1mfgexgf9la/notify.txt?rlkey=cth4799o1l4yu8fcajn6kgend&st=veb74neh&dl=1'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'https://'

'''#####-----Excludes-----#####'''
excludes  = ['']
