import os

IMAGE_EXT = {'.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp'}
KEEP_NAMES = {'settings.xml', 'settings.json', 'profiles.xml'}

ADDON_CACHE_IDS = (
    'script.nimbus.helper',
    'plugin.video.cumination',
    'script.common.plugin.cache',
)


def folder_size(path):
    total = 0
    count = 0
    if not path or not os.path.exists(path):
        return 0, 0
    for root, dirs, files in os.walk(path):
        for name in files:
            fp = os.path.join(root, name)
            try:
                total += os.path.getsize(fp)
                count += 1
            except Exception:
                pass
    return total, count


def fmt_mb(num_bytes):
    return '%.1f MB' % (float(num_bytes) / 1048576.0)


def addon_data_root(translate):
    return translate('special://profile/addon_data')


def addon_cache_paths(translate):
    root = addon_data_root(translate)
    return [os.path.join(root, aid) for aid in ADDON_CACHE_IDS]


def addon_image_stats(translate):
    total = 0
    count = 0
    for base in addon_cache_paths(translate):
        if not os.path.isdir(base):
            continue
        for root, dirs, files in os.walk(base):
            for name in files:
                ext = os.path.splitext(name)[1].lower()
                if ext not in IMAGE_EXT:
                    continue
                fp = os.path.join(root, name)
                try:
                    total += os.path.getsize(fp)
                    count += 1
                except Exception:
                    pass
    return total, count


def purge_addon_images(translate, log=None):
    deleted = 0
    failed = 0
    bytes_freed = 0
    for base in addon_cache_paths(translate):
        if not os.path.isdir(base):
            continue
        for root, dirs, files in os.walk(base):
            for name in files:
                if name in KEEP_NAMES:
                    continue
                ext = os.path.splitext(name)[1].lower()
                if ext not in IMAGE_EXT:
                    continue
                fp = os.path.join(root, name)
                try:
                    size = os.path.getsize(fp)
                    os.unlink(fp)
                    deleted += 1
                    bytes_freed += size
                except Exception as e:
                    failed += 1
                    if log:
                        log('Failed deleting %s: %s' % (fp, e))
    return deleted, failed, bytes_freed


def cleaning_overview(translate, packages_path, thumbs_path, cache_path, temp_path, db_path):
    cache_b, cache_n = folder_size(cache_path)
    temp_b, temp_n = folder_size(temp_path)
    pack_b, pack_n = folder_size(packages_path)
    thumb_b, thumb_n = folder_size(thumbs_path)
    db_b, db_n = folder_size(db_path)
    extra_b, extra_n = addon_image_stats(translate)
    lines = [
        'Schoon te maken (schatting):',
        'Cache: %s (%d files) + Temp: %s (%d files)' % (fmt_mb(cache_b), cache_n, fmt_mb(temp_b), temp_n),
        'Packages: %s (%d files)' % (fmt_mb(pack_b), pack_n),
        'Kodi Thumbnails: %s (%d files)' % (fmt_mb(thumb_b), thumb_n),
        'Databases: %s (%d files)' % (fmt_mb(db_b), db_n),
        'Addon thumbs (nimbus/cumination/plugin.cache): %s (%d png/jpg)' % (fmt_mb(extra_b), extra_n),
    ]
    return '[CR]'.join(lines), {
        'cache': cache_b + temp_b,
        'packages': pack_b,
        'thumbs': thumb_b,
        'db': db_b,
        'addon_thumbs': extra_b,
        'addon_thumbs_count': extra_n,
    }
