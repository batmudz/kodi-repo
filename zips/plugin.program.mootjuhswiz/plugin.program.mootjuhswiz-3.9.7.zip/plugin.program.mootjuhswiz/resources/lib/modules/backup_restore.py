import shutil
import os
import zipfile
from zipfile import ZipFile
from pathlib import Path
from datetime import datetime
import xbmc
import xbmcgui
from .addonvar import (home, addon_profile, addon_path, setting,
                       setting_set, translatePath, xbmcPath, addon_id,
                       dp, local_string, addon_name, addon_icon, addon_fanart, os_name)
from .utils import add_dir
from .colors import colors

COLOR1 = colors.color_text1
COLOR2 = colors.color_text2

p = Path(home)
backup_path = Path(translatePath(setting('backupfolder')))
backups = p / 'backups'
addons = p / 'addons'
media = p / 'media'
userdata = p / 'userdata'
addon_data_dir = userdata / 'addon_data'
wizard_path = Path(addon_path)
data_path = Path(addon_profile)
compression = zipfile.ZIP_DEFLATED

def log(_text, _var):
    xbmc.log(f'{_text} = {str(_var)}', xbmc.LOGINFO)

excludes = [p / 'addons/packages', p / 'addons/temp', p / 'userdata/Thumbnails', p / 'userdata/Database/Textures13.db', p / 'userdata/Database/Textures14.db', p / wizard_path]

# en_us blijft: skin.nimbus levert Engels als en_us, niet als en_gb.
KEEP_LANGS = {
    'resource.language.nl_nl',
    'resource.language.en_gb',
    'resource.language.en_us',
}
CACHE_DIR_NAMES = {'cache', 'caches', 'image_cache'}

def _is_excluded(path):
    for ex in excludes:
        try:
            path.relative_to(ex)
            return True
        except ValueError:
            continue
    for part in path.parts:
        if part.startswith('resource.language.') and part not in KEEP_LANGS:
            return True
    # Alleen userdata. Een map "caches" in de addon-code moet mee, anders is restore stuk.
    try:
        rel = path.relative_to(p)
    except ValueError:
        rel = path
    if not rel.parts or rel.parts[0] != 'userdata':
        return False
    for part in rel.parts:
        if part.lower() in CACHE_DIR_NAMES:
            return True
    name = path.name.lower()
    if name.endswith('.db') and 'cache' in name:
        return True
    if name.startswith('textures') and name.endswith('.db'):
        return True
    return False

def default_backup_name(prefix='Kodi_Backup'):
    return datetime.now().strftime(f'{prefix}_%d-%m-%y-%H%M')

def from_keyboard(default_name=''):
    kb = xbmc.Keyboard(default_name, 'Backupnaam (zip)', False)
    kb.doModal()
    if kb.isConfirmed():
        text = (kb.getText() or '').strip()
        if text.lower().endswith('.zip'):
            text = text[:-4]
        return text or default_name
    return False

def _include_file(file_path, include_dlls):
    return include_dlls or file_path.suffix.lower() != '.dll'

def _ask_backup_target(prefix='Kodi_Backup'):
    backup_path.mkdir(parents=True, exist_ok=True)
    k = from_keyboard(default_backup_name(prefix))
    if k is False:
        xbmcgui.Dialog().ok('Backup', 'Backup geannuleerd')
        return None
    return backup_path / f'{k}.zip'

def _zip_write(zip_file, item, include_dlls=True):
    written = 0
    skipped = 0
    if item.is_dir():
        if _is_excluded(item):
            return 0, 1
        for z in sorted(item.rglob('*')):
            if _is_excluded(z) or not _include_file(z, include_dlls) or '__pycache__' in z.parts:
                skipped += 1
                continue
            try:
                zip_file.write(z, str(z.relative_to(p)), compress_type=compression)
                written += 1
            except Exception as e:
                xbmc.log(f'Unable to compress file {str(z)}: {e}', xbmc.LOGINFO)
    elif item.is_file():
        if _is_excluded(item) or not _include_file(item, include_dlls):
            return 0, 1
        try:
            zip_file.write(item, str(item.relative_to(p)), compress_type=compression)
            written = 1
        except Exception as e:
            xbmc.log(f'Unable to compress file {str(item)}: {e}', xbmc.LOGINFO)
    return written, skipped

def _backup_done(title, backup_name, written, skipped):
    xbmcgui.Dialog().ok(
        title,
        f'{backup_name.name}[CR]{written} bestanden.[CR]{skipped} overgeslagen (cache, thumbs, extra talen).'
    )

def backup_build():
    backup_name = _ask_backup_target('Kodi_Backup')
    if backup_name is None:
        return

    include_dlls = True
    if os_name == 'Windows':
        include_dlls = xbmcgui.Dialog().yesno(
            addon_name,
            COLOR2('Include binary .dll files?[CR][CR]Selecting No will skip .dll files found in any binary addon folders in this backup.'),
            yeslabel='Yes',
            nolabel='No',
            defaultbutton=xbmcgui.DLG_YESNO_YES_BTN
        )

    addons_dirs = [x for x in addons.iterdir() if x.is_dir() and x not in excludes] if addons.exists() else []
    addons_files = [x for x in addons.iterdir() if x.is_file() and x not in excludes] if addons.exists() else []
    media_dirs = [x for x in media.iterdir() if x.is_dir() and x not in excludes] if media.exists() else []
    media_files = [x for x in media.iterdir() if x.is_file() and x not in excludes] if media.exists() else []
    userdata_dirs = [x for x in userdata.iterdir() if x.is_dir() and x not in excludes] if userdata.exists() else []
    userdata_files = [x for x in userdata.iterdir() if x.is_file() and x not in excludes] if userdata.exists() else []

    zip_file = ZipFile(backup_name, 'w')
    xbmcgui.Dialog().notification(addon_name, 'Backup bezig...', addon_icon, 3000)
    written = skipped = 0
    for x in sorted(addons_dirs + addons_files):
        w, s = _zip_write(zip_file, x, include_dlls)
        written += w
        skipped += s
    for x in sorted(media_dirs + media_files + userdata_dirs + userdata_files):
        w, s = _zip_write(zip_file, x, True)
        written += w
        skipped += s
    zip_file.close()
    _backup_done('Backup', backup_name, written, skipped)

def backup_addon_data():
    if not addon_data_dir.exists():
        xbmcgui.Dialog().ok('Backup', 'addon_data map niet gevonden')
        return
    backup_name = _ask_backup_target('Kodi_AddonData')
    if backup_name is None:
        return
    zip_file = ZipFile(backup_name, 'w')
    xbmcgui.Dialog().notification(addon_name, 'addon_data backup bezig...', addon_icon, 3000)
    written, skipped = _zip_write(zip_file, addon_data_dir)
    zip_file.close()
    _backup_done('Backup', backup_name, written, skipped)

excludes_freshstart = [addon_id, 'backups',  'Addons33.db', 'kodi.log']

def fresh_start_restore():
    for root, dirs, files in os.walk(xbmcPath, topdown=True):
        dirs[:] = [d for d in dirs if d not in excludes_freshstart]
        for name in files:
            if name not in excludes_freshstart:
                try:
                    os.unlink(os.path.join(root, name))
                except:
                    log('Error Deleting', name)

    for root, dirs, files in os.walk(xbmcPath,topdown=True):
        dirs[:] = [d for d in dirs if d not in excludes_freshstart]
        for name in dirs:
            if name not in ['addons', 'userdata', 'Database', 'addon_data', 'backups', 'temp']:
                try:
                    shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)
                except:
                    log('Error Deleting', name)

def get_backup_folder():
    dialog = xbmcgui.Dialog()
    fn = dialog.browseSingle(0, 'Kodi', 'local', '', False, False)
    setting_set('backupfolder', fn)

def reset_backup_folder():
    setting_set('backupfolder', 'special://home/backups')
    xbmcgui.Dialog().ok('Backup Folder', 'Backup Folder Location\\nSet to Default')

def restore_menu():
    build_backups = ([x for x in backup_path.iterdir() if x.is_file() and str(x).endswith('.zip')])
    for build in sorted(build_backups, key=lambda x: x.stat().st_mtime, reverse=True):
        add_dir(str(build.stem), str(build), 15, addon_icon, addon_fanart, str(build.name), isFolder=False)

def restore_build(zippath):
    restore = xbmcgui.Dialog().yesno('Restore', 'Are you sure you wish to wipe \\ncurrent data and restore from backup?')
    if restore is True:
        fresh_start_restore()
        if os.path.exists(zippath):
            dp.create('Restore', local_string(30034))
            counter = 1
            with ZipFile(zippath, 'r') as z:
                files = z.infolist()
                for file in files:
                    filename = file.filename
                    filename_path = os.path.join(home, filename)
                    progress_percentage = int(counter/len(files)*100)
                    try:
                        if not os.path.exists(filename_path) or 'Addons33.db' in filename:
                            z.extract(file, home)
                    except Exception as e:
                        xbmc.log(f'Error extracting {filename} - {e}', xbmc.LOGINFO)
                    dp.update(progress_percentage, f'{local_string(30034)}...\\n{progress_percentage}%\\n{filename}')
                    counter += 1
                dp.update(100, local_string(30035))
                xbmcgui.Dialog().ok('Restore', 'Restore Complete')
                setting_set('firstrun', 'true')
                os._exit(1)
        else:
            xbmcgui.Dialog().ok('Restore', 'Backup Not Found')
    else:
        return False
