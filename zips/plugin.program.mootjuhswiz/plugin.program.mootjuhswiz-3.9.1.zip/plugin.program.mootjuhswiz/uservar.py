'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/batmudz/kodi-repo/main/builds.txt'

'''#####-----Videos File-----#####'''
videos_url = 'http://'

'''#####-----Notification File-----#####'''
notify_url  = 'https://www.dropbox.com/scl/fi/sw0oc07yce1mfgexgf9la/notify.txt?rlkey=cth4799o1l4yu8fcajn6kgend&st=veb74neh&dl=1'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'https://'

'''#####-----Excludes-----#####'''
excludes  = ['']
