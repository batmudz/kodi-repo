import xbmc
import xbmcvfs
import os
import random
import shutil

ADDON_SPLASHES = xbmcvfs.translatePath("special://home/addons/script.splash.cycler/resources/splashes/")
USER_SPLASHES = xbmcvfs.translatePath("special://home/media/splashes/")
TARGET_SPLASH = xbmcvfs.translatePath("special://home/media/splash.jpg")


def paths_are_same(src, dst):
    src_norm = os.path.normcase(os.path.abspath(src))
    dst_norm = os.path.normcase(os.path.abspath(dst))
    return src_norm == dst_norm


def safe_copy(src, dst):
    try:
        if paths_are_same(src, dst):
            xbmc.log(f"[Splash] Skipping copy — same file: {src}", xbmc.LOGINFO)
            return
        dst_dir = os.path.dirname(dst)
        if not os.path.exists(dst_dir):
            os.makedirs(dst_dir, exist_ok=True)
        shutil.copy(src, dst)
        xbmc.log(f"[Splash] Copied: {src} → {dst}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Splash] ERROR copying: {e}", xbmc.LOGERROR)


def sync_splashes():
    """Replace user splash folder with images from the addon."""
    if not os.path.exists(ADDON_SPLASHES):
        xbmc.log("[Splash] No resources/splashes/ in addon.", xbmc.LOGWARNING)
        return

    # Clear user folder
    if os.path.exists(USER_SPLASHES):
        for f in os.listdir(USER_SPLASHES):
            try:
                os.remove(os.path.join(USER_SPLASHES, f))
            except Exception as e:
                xbmc.log(f"[Splash] Could not remove {f}: {e}", xbmc.LOGWARNING)
    else:
        os.makedirs(USER_SPLASHES, exist_ok=True)

    # Copy from addon
    copied = 0
    for f in os.listdir(ADDON_SPLASHES):
        if f.lower().endswith(".jpg"):
            src = os.path.join(ADDON_SPLASHES, f)
            dst = os.path.join(USER_SPLASHES, f)
            safe_copy(src, dst)
            copied += 1
    xbmc.log(f"[Splash] Synced {copied} splash images from addon.", xbmc.LOGINFO)


def choose_random_splash():
    if not os.path.exists(USER_SPLASHES):
        xbmc.log("[Splash] Splash folder does not exist.", xbmc.LOGWARNING)
        return

    images = [f for f in os.listdir(USER_SPLASHES)
              if f.lower().endswith(".jpg")]

    if not images:
        xbmc.log("[Splash] No jpg images found.", xbmc.LOGWARNING)
        return

    selected = random.choice(images)
    src = os.path.join(USER_SPLASHES, selected)
    xbmc.log(f"[Splash] Selected: {selected}", xbmc.LOGINFO)
    safe_copy(src, TARGET_SPLASH)


if __name__ == "__main__":
    sync_splashes()
    choose_random_splash()
