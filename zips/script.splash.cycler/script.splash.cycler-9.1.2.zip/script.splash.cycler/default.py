import xbmc
import xbmcaddon
import xbmcvfs
import os
import random
import shutil

ADDON = xbmcaddon.Addon()
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_SPLASHES = xbmcvfs.translatePath("special://home/addons/script.splash.cycler/resources/splashes/")
USER_SPLASHES = xbmcvfs.translatePath("special://home/media/splashes/")
TARGET_SPLASH = xbmcvfs.translatePath("special://home/media/splash.jpg")
VERSION_FILE = xbmcvfs.translatePath("special://home/media/splashes/.version")


def paths_are_same(src, dst):
    src_norm = os.path.normcase(os.path.abspath(src))
    dst_norm = os.path.normcase(os.path.abspath(dst))
    return src_norm == dst_norm


def safe_copy(src, dst):
    try:
        if paths_are_same(src, dst):
            xbmc.log(f"[Splash] Skipping copy — same file: {src}", xbmc.LOGINFO)
            return
        dst_dir = os.path.dirname(dst)
        if not os.path.exists(dst_dir):
            os.makedirs(dst_dir, exist_ok=True)
        shutil.copy(src, dst)
        xbmc.log(f"[Splash] Copied: {src} → {dst}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Splash] ERROR copying: {e}", xbmc.LOGERROR)


def get_stored_version():
    try:
        if os.path.exists(VERSION_FILE):
            with open(VERSION_FILE, 'r') as f:
                return f.read().strip()
    except Exception:
        pass
    return ""


def set_stored_version(ver):
    try:
        os.makedirs(os.path.dirname(VERSION_FILE), exist_ok=True)
        with open(VERSION_FILE, 'w') as f:
            f.write(ver)
    except Exception as e:
        xbmc.log(f"[Splash] Could not write version file: {e}", xbmc.LOGWARNING)


def sync_splashes_if_updated():
    """Replace user splash folder only when addon version has changed."""
    stored = get_stored_version()
    if stored == ADDON_VERSION:
        xbmc.log(f"[Splash] Version {ADDON_VERSION} already synced, skipping.", xbmc.LOGINFO)
        return

    xbmc.log(f"[Splash] Version changed ({stored} → {ADDON_VERSION}), syncing images.", xbmc.LOGINFO)

    if not os.path.exists(ADDON_SPLASHES):
        xbmc.log("[Splash] No resources/splashes/ in addon.", xbmc.LOGWARNING)
        set_stored_version(ADDON_VERSION)
        return

    # Clear user folder
    if os.path.exists(USER_SPLASHES):
        for f in os.listdir(USER_SPLASHES):
            if f == ".version":
                continue
            try:
                os.remove(os.path.join(USER_SPLASHES, f))
            except Exception as e:
                xbmc.log(f"[Splash] Could not remove {f}: {e}", xbmc.LOGWARNING)
    else:
        os.makedirs(USER_SPLASHES, exist_ok=True)

    # Copy from addon
    copied = 0
    for f in os.listdir(ADDON_SPLASHES):
        if f.lower().endswith(".jpg"):
            src = os.path.join(ADDON_SPLASHES, f)
            dst = os.path.join(USER_SPLASHES, f)
            safe_copy(src, dst)
            copied += 1

    set_stored_version(ADDON_VERSION)
    xbmc.log(f"[Splash] Synced {copied} splash images.", xbmc.LOGINFO)


def choose_random_splash():
    if not os.path.exists(USER_SPLASHES):
        xbmc.log("[Splash] Splash folder does not exist.", xbmc.LOGWARNING)
        return

    images = [f for f in os.listdir(USER_SPLASHES)
              if f.lower().endswith(".jpg")]

    if not images:
        xbmc.log("[Splash] No jpg images found.", xbmc.LOGWARNING)
        return

    selected = random.choice(images)
    src = os.path.join(USER_SPLASHES, selected)
    xbmc.log(f"[Splash] Selected: {selected}", xbmc.LOGINFO)
    safe_copy(src, TARGET_SPLASH)


if __name__ == "__main__":
    sync_splashes_if_updated()
    choose_random_splash()
